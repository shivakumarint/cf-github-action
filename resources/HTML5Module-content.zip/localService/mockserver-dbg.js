"use strict";

sap.ui.define(['sap/ui/core/util/MockServer'], function (MockServer) {
  return {
    init: function init() {
      // create
      var oMockServer = new MockServer({
        rootUri: '' // rootUri and manifest dataSource uri should be same

      });
      var oUriParameters = jQuery.sap.getUriParameters(); // configure

      MockServer.config({
        autoRespond: true,
        autoRespondAfter: oUriParameters.get('serverDelay') || 1000
      }); // simulate

      var sPath = jQuery.sap.getModulePath('ui5boilerplate.localService');
      oMockServer.simulate("".concat(sPath, "/metadata.xml"), "".concat(sPath, "/mockdata")); // start

      oMockServer.start();
    }
  };
});