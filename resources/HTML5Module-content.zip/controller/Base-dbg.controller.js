"use strict";

sap.ui.define(['sap/ui/core/mvc/Controller'], function (Controller) {
  return Controller.extend('ui5boilerplate.controller.BaseController', {
    onInit: function onInit() {}
  });
});